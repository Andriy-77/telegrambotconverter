from aiogram import Router, F
from aiogram.types import Message
from settings import DATABASE, CURRENCY_API_URL
from app.database import get_all_conversions, add_conversion
from app.keyboards import menu_keyboards
import aiohttp

router = Router()

@router.message(F.text == "Історія конвертацій")
async def show_history(message: Message):
    conversions = get_all_conversions(DATABASE)
    if not conversions:
        await message.answer("Історія порожня.")
        return
    text = "\n".join(
        f"{conversions['amount']} {conversions['from']} -> {conversions['to']}: {conversions['result']}" in conversions
    )
    await message.answer(text)

@router.message()
async def convert(message: Message):
    parts = message.text.strip().split()
    amount, from_cur, to_cur = parts[0], parts[1].upper(), parts[2].upper()
    try:
        float(amount)
    except ValueError:
        await message.answer("Сума має бути числом.")
        return
    url = f"{CURRENCY_API_URL}/{from_cur}/{to_cur}/{amount}"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            result = await response.json()
    if "conversion_result" in result:
        converted = (result["conversion_result"])
        add_conversion(DATABASE, {
            "amount": amount,
            "from": from_cur,
            "to": to_cur,
            "result": converted,
        })
        await message.answer(
            f"{amount} {from_cur} = {converted} {to_cur}",
            reply_markup=menu_keyboards()
        )
    else:
        await message.answer("Не вдалося отримати результат.")