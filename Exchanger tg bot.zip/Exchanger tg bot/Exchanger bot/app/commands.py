CURRENCY = "currency"
CONVERT_OWN = "convert_custom"