import os
from dotenv import load_dotenv

load_dotenv()

TOKEN = "7613376395:AAHKuZZhIneUh-qELw8fww4OwPs0C-HU-ho"
CURRENCY_API_URL = "https://v6.exchangerate-api.com/v6/1654c49bdd29d968f05e0dff/pair"
DATABASE = "./data.json"